﻿using System;
using System.IO;
using System.Globalization;
using System.Collections.Generic;

namespace Test
{
    class Solution
    {
        static class FormulasHelper
        {
            public static int NormalizeValue(int value, int topValue)
            {
                return (int)(Math.Round(100 * (value / (double)topValue)));
            }

            public static double Spread(double bid, double ask)
            {
                return 100 * (ask - bid) / ask;
            }
        }
    
        static void _Main(string[] args)
        {
            //Main method here
        }

        static void Main(string[] args)
        {
            try
            {
                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();

                var collectionCount = GC.CollectionCount(0);
                var sw = System.Diagnostics.Stopwatch.StartNew();

                _Main(args);

                sw.Stop();
                var elapsed = sw.Elapsed.TotalMilliseconds;
                collectionCount = GC.CollectionCount(0) - collectionCount;

                Console.WriteLine("Time: {0,6} ms (GCs={1,3})", elapsed.ToString("N0", CultureInfo.InvariantCulture), collectionCount);
                Environment.Exit(0);
            }
            catch(Exception e)
            {
                Console.WriteLine(e.ToString());
                Environment.Exit(-1);
            }
        }
    }
}